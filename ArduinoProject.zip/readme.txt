I made this project for my girlfriend because she wanted to try to learn programming. I figured it might be useful to someone else trying to learn and figured I would share it.

This is a project intended for someone looking to get started with an Arduino. The total cost of all of these parts is under $100. You may already have some of the parts already so double check before purchasing (A-B USB cable comes with printers usually, MicroSD card) These projects are a quick introduction to programming and interfacing with various types of sensors and devices. This should be a helpful starting point that will give you some useful tools to use on future projects.

The following tools are required after page 20:

Wire Strippers
Solder
Soldering Iron

The first 2 projects can be done without these tools. You will need to modify the purchase list accordingly, omitting the LCD, MicroSD shield, Potentiometer, and MicroSD Card.

Download the .ZIP file titled complete project and you will have the instructions, parts list, and a few software libraries that will be used.

The code is designed to be simple enough to copy from the pages. I recommend pulling the .pdf up on a tablet or separate laptop so that you can have the directions in front of you while programming.

Enjoy!
-Sean
